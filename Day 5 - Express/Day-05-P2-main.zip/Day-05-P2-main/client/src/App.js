import logo from './logo.svg';
import './App.css';
import MessageSender from './Components/MessegeSender';

function App() {
  return (
    <div className="App">
      <MessageSender/>
    </div>
  );
}

export default App;
