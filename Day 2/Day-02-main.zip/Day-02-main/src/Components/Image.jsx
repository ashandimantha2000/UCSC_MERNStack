import React from 'react';
import Image1 from '../Styles/images/download.jpg';

function MyImage() {
  return (
    <div>
    <img src={Image1} width="200px" height="200px" alt="logo" />
    </div>
  );
}

export default MyImage;
