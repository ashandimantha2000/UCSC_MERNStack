import React from 'react';
import { Button } from '../Styles/button';

function MyStyles() {
  return (
    <div>
      <Button>Click Me</Button>
      <Button>sECOND bUTTON</Button>
    </div>
  );
}

export default MyStyles;
